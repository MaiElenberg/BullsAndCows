﻿using System;
using System.Collections.Generic;

namespace GameUI
{
    public class Program
    {
        public static void Main()
        {
            FormGame boolPgiaGame = new FormGame();
        }
    }
}
